import express from "express";
import pkg from "pg";
import path from "path";
import { fileURLToPath } from "url";

// ES module __dirname fix
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const { Pool } = pkg;
const app = express();
const port = 4001;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// JSON parser
app.use(express.json());

// ✅ serve HTML from same origin (so no CORS needed)
app.use(express.static(__dirname));

app.get("/v1/health", (req, res) => {
  res.json({ ok: true, service: "loyalty-demo-db", time: new Date().toISOString() });
});

app.get("/v1/activities", async (req, res) => {
  try {
    const { rows } = await pool.query(
      "SELECT activity_id, member_id, activity_type, points, created_at FROM activity ORDER BY created_at DESC LIMIT 50;"
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/v1/member/search", async (req, res) => {
  const q = req.query.q?.trim();
  if (!q) return res.status(400).json({ error: "Missing query" });

  try {
    const sql = `
      SELECT member_id, tenant_id, name
      FROM member
      WHERE member_id::text = $1 OR LOWER(name) LIKE LOWER('%' || $1 || '%')
      ORDER BY member_id
    `;
    const { rows } = await pool.query(sql, [q]);
    if (!rows.length) return res.status(404).json({ error: "Not Found" });
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.listen(port, () => {
  console.log(`server_db_fixed.js listening on http://127.0.0.1:${port}`);
});
