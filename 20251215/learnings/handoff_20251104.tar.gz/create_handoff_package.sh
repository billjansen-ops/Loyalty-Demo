#!/bin/bash
# ============================================================================
# Loyalty Platform - Create Handoff Package
# ============================================================================
# Creates a complete handoff package for transitioning to a new chat session
# Includes: code, learning files, schema, and documentation
# ============================================================================

set -e  # Exit on error

# Get timestamp for filename
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
PACKAGE_NAME="loyalty_handoff_${TIMESTAMP}"
TEMP_DIR="/tmp/${PACKAGE_NAME}"

echo "========================================="
echo "Creating Loyalty Platform Handoff Package"
echo "========================================="
echo ""

# ============================================================================
# STEP 1: Capture Database Schema
# ============================================================================
echo "📊 Capturing database schema..."

pg_dump -h 127.0.0.1 \
        -U billjansen \
        -d loyalty \
        --schema-only \
        --no-owner \
        --no-privileges \
        -f learnings/schema_snapshot.sql

if [ -f learnings/schema_snapshot.sql ]; then
    SIZE=$(ls -lh learnings/schema_snapshot.sql | awk '{print $5}')
    echo "   ✓ Schema captured: $SIZE"
else
    echo "   ✗ ERROR: Schema capture failed!"
    exit 1
fi

# ============================================================================
# STEP 2: Create Package Directory Structure
# ============================================================================
echo ""
echo "📦 Creating package structure..."

mkdir -p "${TEMP_DIR}"
mkdir -p "${TEMP_DIR}/learnings"
mkdir -p "${TEMP_DIR}/SQL"

# ============================================================================
# STEP 3: Copy Essential Files
# ============================================================================
echo ""
echo "📄 Copying files..."

# Core application files
echo "   - Application files..."
cp *.html "${TEMP_DIR}/" 2>/dev/null || true
cp *.js "${TEMP_DIR}/" 2>/dev/null || true
cp *.css "${TEMP_DIR}/" 2>/dev/null || true
cp *.json "${TEMP_DIR}/" 2>/dev/null || true

# Learning files (the brain of the project!)
echo "   - Learning files..."
cp learnings/*.md "${TEMP_DIR}/learnings/" 2>/dev/null || true
cp learnings/*.sql "${TEMP_DIR}/learnings/" 2>/dev/null || true

# SQL scripts
echo "   - SQL migration scripts..."
cp SQL/*.sql "${TEMP_DIR}/SQL/" 2>/dev/null || true

# Documentation
echo "   - Documentation..."
cp README*.md "${TEMP_DIR}/" 2>/dev/null || true
cp EXTRACT_HERE.sh "${TEMP_DIR}/" 2>/dev/null || true

# ============================================================================
# STEP 4: Create Manifest
# ============================================================================
echo ""
echo "📋 Creating manifest..."

cat > "${TEMP_DIR}/MANIFEST.txt" << 'EOF'
# Loyalty Platform Handoff Package
# ==================================

## What's Included

### Application Files
- *.html - All admin and user interface pages
- *.js - Client-side scripts and API shim
- *.css - Theme and styling
- server_db_api.js - Main server (Node + Express + PostgreSQL)

### Learning Files (learnings/)
- SESSION_*.md - Daily work summaries
- WORKFLOW_STANDARDS.md - Project conventions ⭐ READ FIRST
- TECHNICAL_DEBT.md - Known issues and future work
- Feature-specific docs (BONUS_*, TIER_*, etc.)
- schema_snapshot.sql - Complete database schema ⭐ IMPORTANT

### SQL Scripts (SQL/)
- Migration scripts
- Schema modifications
- Debug/utility scripts

## Quick Start for New Session

1. READ FIRST:
   - learnings/WORKFLOW_STANDARDS.md
   - learnings/TECHNICAL_DEBT.md
   - Most recent learnings/SESSION_*.md

2. Understand the schema:
   - learnings/schema_snapshot.sql has complete structure

3. Check what's working:
   - Read the most recent SESSION file
   - Look at TECHNICAL_DEBT.md for known issues

4. Start coding:
   - Install files as needed
   - Follow conventions in WORKFLOW_STANDARDS.md
   - Keep learning files updated

## Architecture Notes

- Multi-tenant system (tenant_id isolation)
- Bonus engine with rule criteria evaluation
- Activity-based point accrual
- Temporal design (activity_date drives everything)
- PostgreSQL database on localhost

## Important Conventions

- SQL scripts go in SQL/ folder
- Documentation uses .md format
- tenant_id should be SMALLINT (not BIGINT/INTEGER)
- Token warnings at 130k, 150k, 170k
- All admin pages use lp-nav.js for navigation

## Key Files

server_db_api.js - Main server
admin_bonus_edit.html - Visual rule builder
lp-nav.js - Central navigation
theme.css - Shared styling

EOF

echo "   ✓ Manifest created"

# ============================================================================
# STEP 5: Create README for new chat
# ============================================================================
echo ""
echo "📝 Creating README..."

cat > "${TEMP_DIR}/README_NEW_CHAT.md" << 'EOF'
# Welcome to Loyalty Platform Session

## 🚀 Quick Start

You're receiving this handoff package to continue work on the Loyalty Platform.

### First Steps (5 minutes)

1. **Read these files in order:**
   ```
   learnings/WORKFLOW_STANDARDS.md    ← Project conventions
   learnings/TECHNICAL_DEBT.md        ← Known issues
   learnings/SESSION_[latest].md      ← Yesterday's work
   ```

2. **Review the schema:**
   ```
   learnings/schema_snapshot.sql      ← Complete database structure
   ```

3. **Understand current priorities:**
   - Check the TODO section in latest SESSION file
   - Check TECHNICAL_DEBT.md for priorities

### Understanding Bill's Working Style

- **Direct communicator** - will tell you if hypothesis is wrong
- **Appreciates thorough documentation** - hence all these learning files
- **Performance-minded** - references "million years ago" system (1980s)
- **Right-sizing advocate** - tenant_id should be SMALLINT, not BIGINT
- **Token aware** - wants warnings at 130k, 150k, 170k tokens

### Key Architectural Decisions

- **Multi-tenant isolation** through tenant_id in member table (others inherit)
- **Temporal-first design** - activity_date drives all logic
- **Bonus engine** - rule-based with criteria evaluation
- **No tenant_id in activity tables** - isolation through member relationship

### Common Mistakes to Avoid

❌ Assuming tables need tenant_id (check inheritance first)  
❌ Not reading WORKFLOW_STANDARDS.md  
❌ Using .txt instead of .md for documentation  
❌ Placing SQL scripts outside SQL/ folder  
❌ Using BIGINT for tenant_id (should be SMALLINT)

### Database Connection

```bash
Host: 127.0.0.1
User: billjansen
Database: loyalty
```

### Starting the Server

```bash
cd ~/Projects/Loyalty-Demo
node server_db_api.js
# Server runs on port 4001
```

### When in Doubt

1. Check WORKFLOW_STANDARDS.md
2. Look at similar existing files
3. Ask Bill - he knows what he wants!

---

**Ready to start coding?** Read those three learning files first! 🎯
EOF

echo "   ✓ README created"

# ============================================================================
# STEP 6: Create Tarball
# ============================================================================
echo ""
echo "🗜️  Creating tarball..."

cd /tmp
tar -czf "${PACKAGE_NAME}.tar.gz" "${PACKAGE_NAME}"

# Move to uploads directory
mkdir -p ~/Projects/Loyalty-Demo/uploads
mv "${PACKAGE_NAME}.tar.gz" ~/Projects/Loyalty-Demo/uploads/

# Cleanup
rm -rf "${TEMP_DIR}"

echo "   ✓ Package created"

# ============================================================================
# STEP 7: Summary
# ============================================================================
echo ""
echo "========================================="
echo "✅ Handoff Package Created Successfully!"
echo "========================================="
echo ""
echo "📦 Package: ~/Projects/Loyalty-Demo/uploads/${PACKAGE_NAME}.tar.gz"
echo ""
echo "📊 Package Contents:"
ls -lh ~/Projects/Loyalty-Demo/uploads/${PACKAGE_NAME}.tar.gz
echo ""
echo "📁 Files included:"
echo "   - All HTML, JS, CSS files"
echo "   - All learning files from learnings/"
echo "   - Complete database schema"
echo "   - All SQL migration scripts"
echo "   - README and MANIFEST"
echo ""
echo "🎯 Next Steps:"
echo "   1. This file is ready to upload to new chat"
echo "   2. New Claude should read WORKFLOW_STANDARDS.md first"
echo "   3. New Claude should read latest SESSION file"
echo "   4. New Claude should review TECHNICAL_DEBT.md"
echo ""
echo "✨ Happy coding!"
echo ""
