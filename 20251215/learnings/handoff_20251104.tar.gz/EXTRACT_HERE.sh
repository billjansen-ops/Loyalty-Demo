#!/bin/bash
# Extract handoff package
# Usage: ./EXTRACT_HERE.sh

echo "Extracting Loyalty Platform files..."
tar -xzf loyalty_handoff_*.tar.gz
echo "Done! Files extracted to current directory."
echo ""
echo "Next steps:"
echo "1. cd to the extracted directory"
echo "2. Run: node server_db_api.js"
echo "3. Open: http://localhost:4001/csr.html"
