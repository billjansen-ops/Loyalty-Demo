/**
 * server_db_fixed.js — ES module
 * GET /v1/health
 * GET /v1/activities -> real rows from Postgres `activity`
 */
import express from 'express';
import cors from 'cors';
import pkg from 'pg';
const { Pool } = pkg;

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: 'billjansen',
  host: 'localhost',
  database: 'loyalty',
  port: 5432,
});

app.get('/v1/health', (req, res) => {
  res.json({ ok: true, service: 'loyalty-demo-db', time: new Date().toISOString() });
});

app.get('/v1/activities', async (req, res) => {
  const limit = Math.max(1, Math.min(parseInt(req.query.limit || '20', 10) || 20, 200));
  try {
    // First try to order by created_at
    let sql = 'select to_jsonb(a) as row from activity a order by a.created_at desc limit $1';
    let result;
    try {
      result = await pool.query(sql, [limit]);
    } catch (e) {
      // If created_at is missing, fall back to no ordering
      sql = 'select to_jsonb(a) as row from activity a limit $1';
      result = await pool.query(sql, [limit]);
    }
    const activities = result.rows.map(r => r.row);
    res.json({ ok: true, count: activities.length, activities });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.use((req, res) => {
  res.status(404).json({ error: 'Not Found', path: req.path });
});

const PORT = process.env.PORT || 4001;
app.listen(PORT, () => {
  console.log(`server_db_fixed.js listening on http://127.0.0.1:${PORT}`);
});
