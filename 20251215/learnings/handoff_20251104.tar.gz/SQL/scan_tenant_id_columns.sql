-- Find all tables that have a tenant_id column
SELECT 
    table_name,
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default
FROM information_schema.columns
WHERE column_name = 'tenant_id'
  AND table_schema = 'public'
ORDER BY table_name;

-- Show the current size of tenant_id in each table
\echo ''
\echo '=== Current tenant_id Data Types ==='
\echo ''

-- Get more detail including constraints
SELECT 
    c.table_name,
    c.column_name,
    c.data_type,
    c.is_nullable,
    (SELECT COUNT(*) 
     FROM information_schema.table_constraints tc
     JOIN information_schema.key_column_usage kcu 
       ON tc.constraint_name = kcu.constraint_name
     WHERE tc.table_name = c.table_name 
       AND kcu.column_name = 'tenant_id'
       AND tc.constraint_type = 'FOREIGN KEY') as has_fk
FROM information_schema.columns c
WHERE c.column_name = 'tenant_id'
  AND c.table_schema = 'public'
ORDER BY c.table_name;
