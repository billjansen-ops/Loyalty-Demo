# Loyalty Platform - New Chat Handoff

## Quick Start

**You're picking up a working loyalty platform CSR console.**

### What's Already Built

1. **CSR Search & Member Lookup** ✅
   - Search by member ID or name
   - Live database integration
   - Member header with context

2. **Member Tier System** ✅
   - Database schema (tier_definition, member_tier)
   - Tier history tracking
   - Support for overlapping tiers (retro-credit)
   - Tier ranking system (higher number = higher tier)

3. **Activity Page** ✅ (structure)
   - Generic activity table (kind, subtype, point_amount)
   - Ready for multiple activity types

4. **Point Summary** ✅ (basic)
   - Display framework in place

5. **Navigation** ✅
   - Centralized in lp-nav.js
   - Single place to manage all nav items

### What's Next

**Priority 1: Bonuses**
- Earn rules and multipliers
- Tier-based bonuses
- Activity type bonuses

**Priority 2: Promotions**
- Opt-in tracking
- Qualification logic
- Progress tracking

**Priority 3: Testing**
- End-to-end flows
- Data validation

### Key Files

- `server_db_api.js` - Express server with all endpoints
- `lp-nav.js` - Navigation logic and rendering
- `tier_schema.sql` - Tier system database schema
- `*.html` - All CSR pages
- `CHECKPOINT_*.md` - Detailed documentation

### Database Schema

**Tables:**
- `member` - Member profiles
- `activity` - All member activities (generic structure)
- `tier_definition` - Available tiers (Basic, Silver, Gold, Platinum)
- `member_tier` - Member tier history with date ranges

**Key Functions:**
- `get_member_tier_on_date(member_id, date)` - Get tier on specific date
- `get_member_current_tier(member_id)` - Get current tier

### Running the System

```bash
# Start server
node server_db_api.js

# Server runs on port 4001
# Open: http://localhost:4001/csr.html

# Database connection uses env vars or defaults:
# PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD
```

### Important Design Decisions

1. **Tier Ranking:** Higher number = higher tier (7=Platinum, 5=Gold, etc.)
2. **Overlapping Tiers:** Supported for retro-credit scenarios
3. **Generic Activity:** Can handle multiple types (not just flights)
4. **Centralized Nav:** All pages use dynamic navigation from lp-nav.js

### Sunday Deadline Context

Building proof of concept to decide: Start own loyalty platform company vs. join existing one.

**Success Criteria:**
- Bonuses working
- Promotions working
- See the data (formatting can wait)

Read the CHECKPOINT documents for complete details.
