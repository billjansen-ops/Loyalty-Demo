// server_db_fixed.js — STATIC + API on 4001, magic = "Billy Likes: <origin>"
// - Serves local HTML (menu.html, activity.html, etc.) and provides API.
// - SQL returns date/type/amount; 'magic' is assembled in-process from activity_detail.k='origin'.
// - Uses column: point_amount (per your schema).
//
// Start (one line):
//   PGHOST=localhost PGPORT=5432 PGDATABASE=loyalty PGUSER=$USER node server_db_fixed.js

import express from 'express';
import pg from 'pg';

const { Pool } = pg;
const app = express();
const pool = new Pool();              // uses PG env vars
const PORT = process.env.PORT || 4001;

// Serve your static files (same origin as API).
app.use(express.static('.'));
app.use(express.json());

// Helper: fetch origins for a set of activity_ids in one query
async function loadOriginsMap(ids) {
  if (!ids.length) return new Map();
  // Ensure bigint[] param by casting in SQL
  const sql = `
    select activity_id, v_text as origin
    from public.activity_detail
    where k = 'origin'
      and activity_id = any($1::bigint[]);
  `;
  const r = await pool.query(sql, [ids]);
  const m = new Map();
  for (const row of r.rows) {
    m.set(Number(row.activity_id), row.origin);
  }
  return m;
}

// --- Activities (adds magic in-process) ---
app.get('/v1/member/:id/activities', async (req, res) => {
  try {
    const { id } = req.params;
    const sql = `
      select
        a.activity_id::bigint       as activity_id,
        a.member_id::bigint         as member_id,
        coalesce(a.point_amount, 0) as point_amount,
        a.point_type                as point_type,
        a.activity_date             as created_at
      from public.activity a
      where a.member_id = $1
      order by a.activity_date desc, a.activity_id desc
      limit 200;
    `;
    const base = await pool.query(sql, [id]);
    const rows = base.rows ?? [];

    // Build origins map and inject "magic"
    const ids = rows.map(r => Number(r.activity_id));
    const origins = await loadOriginsMap(ids);

    const shaped = rows.map(r => ({
      activity_id: String(r.activity_id),
      member_id: String(r.member_id),
      points: String(r.point_amount ?? 0),
      point_type: r.point_type,
      created_at: r.created_at,
      magic: (origins.get(Number(r.activity_id)) ? `Billy Likes: ${origins.get(Number(r.activity_id))}` : 'Billy Likes: ')
    }));

    res.json(shaped);
  } catch (err) {
    console.error('Error fetching activities', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// --- Balances ---
app.get('/v1/member/:id/balances', async (req, res) => {
  try {
    const { id } = req.params;
    const sql = `
      select coalesce(sum(point_amount),0)::bigint as base_miles
      from public.activity
      where member_id = $1 and point_type = 'miles';
    `;
    const r = await pool.query(sql, [id]);
    const base_miles = Number(r.rows[0]?.base_miles || 0);
    res.json({ base_miles, tier_credits: 0 });
  } catch (err) {
    console.error('Error fetching balances', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// --- Member search ---
app.get('/v1/member/search', async (req, res) => {
  try {
    const qRaw = (req.query.q ?? '').toString().trim();
    if (!qRaw) return res.json([]);
    const q = qRaw.toLowerCase();
    const sql = `
      select member_id::text, tenant_id::text, name
      from public.member
      where lower(coalesce(name,'')) like '%' || $1 || '%'
         or member_id::text like '%' || $1 || '%'
      order by member_id
      limit 50;
    `;
    const r = await pool.query(sql, [q]);
    res.json(r.rows);
  } catch (err) {
    console.error('Error in search', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(PORT, () => {
  console.log(`server_db_fixed.js (static + API) on http://127.0.0.1:${PORT}`);
});
