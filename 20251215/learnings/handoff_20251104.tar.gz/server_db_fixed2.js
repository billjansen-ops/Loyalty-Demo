import express from "express";
import cors from "cors";
import { Pool } from "pg";
import { fileURLToPath } from "url";
import { dirname } from "path";

// ESM __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(__dirname));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgres:///loyalty",
});

// ---- Health ----
app.get("/v1/health", (_req, res) => {
  res.json({ ok: true, service: "loyalty-demo-db", time: new Date().toISOString() });
});

// ---- Canonical endpoints (normalized keys) ----
app.get("/v1/activities", async (_req, res) => {
  try {
    const sql = `
  select
    a.activity_id::text,
    a.member_id::text,
    coalesce(a.point_amount,0)::text as points,
    a.point_type,
    a.activity_date as created_at,
    jsonb_build_object(
      'origin',
      (select ad.v_text
         from public.activity_detail ad
        where ad.activity_id = a.activity_id
          and ad.k = 'origin')
    ) as details
  from public.activity a
  where a.member_id = 
  order by a.activity_date desc, a.activity_id desc
  limit 200
`;
    const { rows } = await pool.query(sql);
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/v1/member/:id/activities", async (req, res) => {
  try {
    const id = req.params.id;
    const sql = `
      SELECT activity_id,
             member_id,
             point_amount AS points,
             point_type,
             (activity_date::timestamp at time zone 'UTC') AS created_at
      FROM activity
      WHERE member_id = $1::bigint
      ORDER BY activity_date DESC, activity_id DESC
      LIMIT 200;
    `;
    const { rows } = await pool.query(sql, [id]);
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/v1/member/:id/balances", async (req, res) => {
  try {
    const id = req.params.id;
    const sql = `
      SELECT
        COALESCE(SUM(CASE WHEN point_type = 'miles' THEN point_amount ELSE 0 END), 0) AS base_miles,
        COALESCE(SUM(CASE WHEN point_type = 'tier'  THEN point_amount ELSE 0 END), 0) AS tier_credits
      FROM activity
      WHERE member_id = $1::bigint;
    `;
    const { rows } = await pool.query(sql, [id]);
    const r = rows[0] || { base_miles: 0, tier_credits: 0 };
    res.json({ base_miles: Number(r.base_miles || 0), tier_credits: Number(r.tier_credits || 0) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get("/v1/member/search", async (req, res) => {
  const q = (req.query.q || "").toString().trim();
  if (!q) return res.status(400).json({ error: "Missing query" });
  try {
    if (/^\d+$/.test(q)) {
      const { rows } = await pool.query(
        `SELECT member_id, tenant_id, name FROM member WHERE member_id = $1::bigint LIMIT 1`,
        [q]
      );
      if (!rows.length) return res.status(404).json([]);
      return res.json(rows);
    } else {
      const { rows } = await pool.query(
        `SELECT member_id, tenant_id, name FROM member WHERE name ILIKE $1 ORDER BY name LIMIT 50`,
        [`%${q}%`]
      );
      if (!rows.length) return res.status(404).json([]);
      return res.json(rows);
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Internal server error" });
  }
});

// ---- Legacy compatibility shims (so existing CSR/activity.html keeps working) ----
// Legacy singular path and camelCase keys
app.get("/v1/member/:id/activity", async (req, res) => {
  try {
    const id = req.params.id;
    const sql = `
      SELECT activity_id,
             member_id,
             point_amount AS points,
             point_type,
             (activity_date::timestamp at time zone 'UTC') AS created_at
      FROM activity
      WHERE member_id = $1::bigint
      ORDER BY activity_date DESC, activity_id DESC
      LIMIT 200;
    `;
    const { rows } = await pool.query(sql, [id]);
    const items = rows.map(r => ({
      id: String(r.activity_id),
      memberId: String(r.member_id),
      points: Number(r.points ?? 0),
      type: r.point_type || "miles",
      createdAt: r.created_at
    }));
    res.json(items);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Legacy balances with camelCase keys
app.get("/v1/member/:id/balances-legacy", async (req, res) => {
  try {
    const id = req.params.id;
    const sql = `
      SELECT
        COALESCE(SUM(CASE WHEN point_type = 'miles' THEN point_amount ELSE 0 END), 0) AS base_miles,
        COALESCE(SUM(CASE WHEN point_type = 'tier'  THEN point_amount ELSE 0 END), 0) AS tier_credits
      FROM activity
      WHERE member_id = $1::bigint;
    `;
    const { rows } = await pool.query(sql, [id]);
    const r = rows[0] || { base_miles: 0, tier_credits: 0 };
    res.json({ baseMiles: Number(r.base_miles || 0), tierCredits: Number(r.tier_credits || 0) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Internal server error" });
  }
});

const PORT = process.env.PORT || 4001;
app.listen(PORT, () => {
  console.log(`server_db_fixed.js listening on http://127.0.0.1:${PORT}`);
});
