# Tables with tenant_id Analysis

## Tables Found in Server Code

From scanning server_db_api.js and learning files:

### **Core Tables:**
1. **tenant** - Master table (tenant_id is PRIMARY KEY)
2. **member** - CRITICAL - holds loyalty members
3. **activity** - Activity records (flights, purchases, etc.)
4. **activity_detail** - Detail lines for activities
5. **activity_bonus** - Bonuses applied to activities
6. **point_lot** - Point balance buckets

### **Configuration Tables:**
7. **bonus** - Bonus rules ✅ Already has tenant_id
8. **carriers** - Airlines/brands ✅ Already has tenant_id
9. **airports** - Airport codes ⚠️ Mentioned in TENANT_FILTERING.md
10. **tier_definition** - Tier levels ✅ Already has tenant_id
11. **point_expiration_rule** - Point expiry policies
12. **molecule_def** - Program-specific molecule definitions

### **Rule Engine Tables:**
13. **rule** - (if exists)
14. **rule_criteria** - Rule criteria definitions
15. **rule_criteria_group** - (if exists)

### **Relationship Tables:**
16. **member_tier** - Member tier assignments/history
17. **tenant_config** - Tenant-specific configuration (mentioned in TECHNICAL_DEBT.md)
18. **tenant_settings** - Tenant settings (mentioned in TECHNICAL_DEBT.md)

---

## Priority Order for Migration

### **CRITICAL - Must Have tenant_id:**
- **member** - The most important! Members belong to specific tenants
- **activity** - Activities are tenant-specific
- **activity_detail** - Inherits from activity
- **activity_bonus** - Tenant-specific bonuses applied
- **point_lot** - Member's points are tenant-isolated
- **member_tier** - Tier assignments are tenant-specific

### **Already Done (from docs):**
- ✅ tenant (primary key)
- ✅ bonus
- ✅ carriers
- ✅ tier_definition

### **Should Have tenant_id:**
- airports (if used as lookup)
- point_expiration_rule
- molecule_def (if tenant-specific definitions)
- rule_criteria (if bonuses are tenant-specific, rules are too)

### **May NOT Need tenant_id:**
- Tables that are truly global/shared across all tenants
- System/audit tables
- Lookup tables that are universal

---

## Recommended SQL Script to Run

Run this first to see what actually exists in your database:

```bash
psql -h 127.0.0.1 -U billjansen -d loyalty -f SQL/scan_tenant_id_columns.sql
```

This will show:
1. All tables that currently have tenant_id
2. The current data type (INTEGER, BIGINT, SMALLINT)
3. Whether they have foreign key constraints

---

## Next Steps

1. **Run the scan script** to see actual current state
2. **Identify which tables are missing tenant_id** (especially member!)
3. **Create migration script** to:
   - Add tenant_id to tables that need it
   - Convert all tenant_id columns to SMALLINT
   - Update foreign key constraints
4. **Test migration** on copy of data
5. **Apply to production**

---

## Migration Order

Should be done in this order to avoid FK constraint issues:

1. **tenant** table first (it's the parent)
2. **All child tables** that reference tenant
3. **Tables that don't reference tenant** (if any have tenant_id for other reasons)

---

## Question for Bill

Before I create the full migration script, please run:

```bash
psql -h 127.0.0.1 -U billjansen -d loyalty -f SQL/scan_tenant_id_columns.sql
```

This will tell us:
- Which tables already have tenant_id
- What data type they currently use
- Whether member table has tenant_id (CRITICAL!)

Then I can create a precise migration script!
