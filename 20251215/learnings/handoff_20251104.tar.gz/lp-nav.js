// Loyalty Platform - Unified Navigation System
// Single source of truth for CSR and Admin navigation

(function() {
  'use strict';

  // Global state
  window.LP_STATE = {
    apiBase: 'http://127.0.0.1:4001',
    version: '1.0.0'
  };

  // Navigation definitions
  const NAV_CONFIGS = {
    csr: [
      { icon: '🔍', label: 'Search', href: 'csr.html' },
      { icon: '👤', label: 'Profile', href: 'profile.html', needsMemberId: true },
      { icon: '📊', label: 'Activity', href: 'activity.html', needsMemberId: true },
      { icon: '💰', label: 'Mile Summary', href: 'point-summary.html', needsMemberId: true, usePointLabel: true },
      { icon: '🎁', label: 'Promotions', href: 'promotions.html', needsMemberId: true },
      { icon: '👥', label: 'Aliases', href: 'aliases.html', needsMemberId: true },
      { icon: '⭐', label: 'Tiers', href: 'tier.html', needsMemberId: true },
      { icon: '📧', label: 'Communications', href: 'communications.html', needsMemberId: true }
    ],
    admin: [
      { icon: '📊', label: 'Overview', href: 'admin.html' },
      { icon: '🧬', label: 'Program Molecules', href: 'admin_molecules.html' },
      { icon: '🎁', label: 'Bonuses', href: 'admin_bonuses.html' },
      { icon: '✈️', label: 'Carriers', href: 'admin_carriers.html' },
      { icon: '⭐', label: 'Tiers', href: 'admin_tiers.html' },
      { icon: '🌍', label: 'Airports', href: 'admin_airports.html' }
    ],
    mainMenu: [
      { icon: '👤', label: 'CSR', href: 'csr.html' },
      { icon: '⚙️', label: 'Admin', href: 'admin.html' },
      { icon: '🏠', label: 'Home', href: 'menu.html' }
    ]
  };

  // Detect page type based on filename
  function getPageType() {
    const path = window.location.pathname;
    const filename = path.split('/').pop();
    
    if (filename.startsWith('admin')) {
      return 'admin';
    } else if ([
      'csr.html', 
      'activity.html', 
      'point-summary.html', 
      'profile.html',
      'promotions.html',
      'aliases.html',
      'tier.html',
      'communications.html'
    ].includes(filename)) {
      return 'csr';
    }
    return null;
  }

  // Build navigation HTML
  function buildNav(pageType) {
    const currentPage = window.location.pathname.split('/').pop();
    const urlParams = new URLSearchParams(window.location.search);
    const memberId = urlParams.get('memberId');
    
    let html = '';
    
    // Add section title
    const sectionTitle = pageType === 'admin' ? 'Client Admin' : 'CSR Console';
    html += `<div class="nav-section-title">${sectionTitle}</div>`;
    
    // Add nav items
    const navItems = NAV_CONFIGS[pageType] || [];
    navItems.forEach(item => {
      let href = item.href;
      
      // Add memberId to URLs that need it
      if (item.needsMemberId && memberId) {
        href += `?memberId=${encodeURIComponent(memberId)}`;
      }
      
      const isActive = currentPage === item.href;
      const activeClass = isActive ? ' active' : '';
      
      html += `
        <a href="${href}" class="nav-item${activeClass}">
          <span class="nav-icon">${item.icon}</span>
          <span>${item.label}</span>
        </a>
      `;
    });
    
    // Add divider and main menu
    html += '<div class="nav-divider"></div>';
    html += '<div class="nav-section-title">Main Menu</div>';
    
    NAV_CONFIGS.mainMenu.forEach(item => {
      const isActive = currentPage === item.href;
      const activeClass = isActive ? ' active' : '';
      
      html += `
        <a href="${item.href}" class="nav-item${activeClass}">
          <span class="nav-icon">${item.icon}</span>
          <span>${item.label}</span>
        </a>
      `;
    });
    
    return html;
  }

  // Initialize navigation on page load
  document.addEventListener('DOMContentLoaded', function() {
    const pageType = getPageType();
    
    if (!pageType) {
      // Not a CSR or Admin page, skip nav injection
      return;
    }
    
    // Find nav container
    const navContainer = document.querySelector('#nav-container, .nav');
    
    if (!navContainer) {
      console.warn('LP-NAV: No navigation container found');
      return;
    }
    
    // Build and inject nav HTML
    const navHTML = buildNav(pageType);
    navContainer.innerHTML = navHTML;
    
    console.log('LP-NAV: Navigation loaded for', pageType);
  });

  // Export utility functions
  window.LP_NAV = {
    getPageType: getPageType,
    buildNav: buildNav,
    setCurrentMember: function(member) {
      // Store current member in sessionStorage
      if (member && member.id) {
        sessionStorage.setItem('currentMember', JSON.stringify(member));
      }
    },
    getCurrentMember: function() {
      const stored = sessionStorage.getItem('currentMember');
      return stored ? JSON.parse(stored) : null;
    },
    navigateTo: function(page, member) {
      if (member && member.id) {
        window.location.href = `${page}?memberId=${encodeURIComponent(member.id)}`;
      } else {
        window.location.href = page;
      }
    },
    version: '1.0.0'
  };

})();
